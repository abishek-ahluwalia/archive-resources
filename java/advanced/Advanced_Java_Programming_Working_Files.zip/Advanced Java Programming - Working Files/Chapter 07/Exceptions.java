public class Exceptions {
   public static void main(String[] args) {
      /*int numer = 12;
      int denom = 0;
      System.out.print(numer / denom);*/
      int[] nums = new int[]{1,2,3};
      System.out.print(nums[5]);
   }
}