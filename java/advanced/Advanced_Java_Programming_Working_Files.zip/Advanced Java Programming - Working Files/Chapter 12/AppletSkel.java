import java.awt.*;
import java.applet.*;

public class AppletSkel extends Applet {

   init() // initialize variables

   start() 

   paint()

   update() 

   stop()

   destroy()

}