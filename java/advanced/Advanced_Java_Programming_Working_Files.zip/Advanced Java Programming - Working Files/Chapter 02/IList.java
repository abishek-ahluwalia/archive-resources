public interface IList<T> {
   void add(T element);
   T get(int n);
}